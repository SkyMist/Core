// $Id: Active_Map_Manager.cpp 91286 2010-08-05 09:04:31Z johnnyw $

#include "ace/Active_Map_Manager.h"

#if !defined (__ACE_INLINE__)
#include "ace/Active_Map_Manager.inl"
#endif /* __ACE_INLINE__ */
