// $Id: Encoding_Converter.cpp 80826 2008-03-04 14:51:23Z wotte $
#include "ace/Encoding_Converter.h"

#if defined (ACE_USES_WCHAR)
ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Encoding_Converter::~ACE_Encoding_Converter (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
#endif /* ACE_USES_WCHAR */
