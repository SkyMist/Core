// $Id: config-macosx-iOS-simulator.h 94431 2011-08-31 11:36:49Z sowayaa $
#ifndef ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H
#define ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H

#define ACE_HAS_IPHONE
#include "ace/config-macosx-lion.h"

#endif /* ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H */

