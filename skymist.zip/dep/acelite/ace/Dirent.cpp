// $Id: Dirent.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/Dirent.h"

#if !defined (__ACE_INLINE__)
#include "ace/Dirent.inl"
#endif /* __ACE_INLINE__ */
